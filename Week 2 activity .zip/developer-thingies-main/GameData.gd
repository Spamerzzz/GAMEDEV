extends Node

var difficulty = "easy"
var deaths = 0
var time_started = 0.0
var time_finished = 0.0
var jumps = 0
var checkpoint_position = Vector2(90, 0)
func reset_stats():
	deaths = 0
	jumps = 0
	time_started = Time.get_ticks_msec()

func get_time_elapsed():
	return (time_finished - time_started) / 1000.0
