extends Node

@onready var player = $"../Player"
@onready var notification_label = $Level2Notification

var level2_started = false

func _ready():
	notification_label.visible = false
	player.set_checkpoint(Vector2(90, 0))

func enter_level2():
	if not level2_started:
		level2_started = true
		player.set_checkpoint(get_level2_start())
		show_notification()

func get_level2_start():
	return Vector2(5000, 0)

func show_notification():
	notification_label.visible = true
	notification_label.text = "Level 2!"
	await get_tree().create_timer(2.0).timeout
	notification_label.visible = false
