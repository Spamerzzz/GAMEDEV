extends Node2D

@onready var tilemap = $Layer0

const GROUND_ROW = 9
const TILE_SIZE = 64

var min_gap = 1
var max_gap = 2
var max_spikes = 0
var platform_min = 14
var platform_max = 20
var level2_reached = false
var stats_showing = false
var player = null

func _ready():
	randomize()
	player = get_tree().get_root().find_child("Player", true, false)
	set_difficulty()
	generate_level()
	
	var goal_line = get_tree().get_root().find_child("GoalLine", true, false)
	if goal_line:
		goal_line.body_entered.connect(_on_goal_entered)

func set_difficulty():
	match GameData.difficulty:
		"easy":
			min_gap = 3
			max_gap = 5
			max_spikes = 1
			platform_min = 12
			platform_max = 18
		"medium":
			min_gap = 4
			max_gap = 6
			max_spikes = 2
			platform_min = 7
			platform_max = 12
		"hard":
			min_gap = 5
			max_gap = 8
			max_spikes = 4
			platform_min = 4
			platform_max = 8

func generate_level():
	var x = 0

	# Long safe start
	fill_ground(0, 20)
	x = 21

	# Level 1
	while x < 80:
		var platform_length = randi_range(platform_min, platform_max)
		fill_ground(x, x + platform_length)

		var safe_landing = 6
		var safe_takeoff = 6
		var spike_zone_start = x + safe_landing
		var spike_zone_end = x + platform_length - safe_takeoff

		if max_spikes > 0 and spike_zone_end > spike_zone_start + 3:
			var spike_count = randi_range(0, max_spikes)
			var used_positions = []
			for i in range(spike_count):
				var attempts = 0
				while attempts < 10:
					var spike_x = randi_range(spike_zone_start, spike_zone_end)
					var too_close = false
					for used in used_positions:
						if abs(spike_x - used) < 4:
							too_close = true
							break
					if not too_close:
						place_spike(spike_x)
						used_positions.append(spike_x)
						break
					attempts += 1

		x += platform_length
		var gap = randi_range(min_gap, max_gap)
		x += gap

	# Safe bridge to level 2
	fill_ground(x, x + 10)
	place_level2_trigger(x + 5)
	x += 12

	# Level 2
	var level2_start = x
	while x < level2_start + 100:
		var platform_length = randi_range(max(platform_min - 4, 7), platform_max - 2)
		fill_ground(x, x + platform_length)

		var safe_landing = 4
		var safe_takeoff = 4
		var spike_zone_start = x + safe_landing
		var spike_zone_end = x + platform_length - safe_takeoff

		if max_spikes > 0 and spike_zone_end > spike_zone_start + 3:
			var spike_count = randi_range(1, max_spikes + 2)
			var used_positions = []
			for i in range(spike_count):
				var attempts = 0
				while attempts < 10:
					var spike_x = randi_range(spike_zone_start, spike_zone_end)
					var too_close = false
					for used in used_positions:
						if abs(spike_x - used) < 3:
							too_close = true
							break
					if not too_close:
						place_spike(spike_x)
						used_positions.append(spike_x)
						break
					attempts += 1

		x += platform_length
		var gap = randi_range(min_gap + 1, max_gap + 2)
		x += gap

	# Safe ending — no place_goal_line() since we use the GoalLine node in scene
	fill_ground(x, x + 12)

func fill_ground(x_start, x_end):
	for x in range(x_start, x_end + 1):
		tilemap.set_cell(Vector2i(x, GROUND_ROW), 0, Vector2i(0, 0))
		tilemap.set_cell(Vector2i(x, GROUND_ROW + 1), 0, Vector2i(0, 0))
		tilemap.set_cell(Vector2i(x, GROUND_ROW + 2), 0, Vector2i(0, 0))

func place_spike(x):
	var spike = Area2D.new()
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = Vector2(55, 55)
	collision.shape = shape
	spike.add_child(collision)
	spike.position = Vector2(x * TILE_SIZE + 32, (GROUND_ROW * TILE_SIZE) - 30)
	spike.body_entered.connect(_on_spike_body_entered)
	add_child(spike)

	var polygon = Polygon2D.new()
	polygon.polygon = PackedVector2Array([
		Vector2(-30, 30),
		Vector2(30, 30),
		Vector2(0, -30)
	])
	polygon.color = Color(1, 0, 0)
	spike.add_child(polygon)

func place_level2_trigger(x):
	var trigger = Area2D.new()
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = Vector2(10, 500)
	collision.shape = shape
	trigger.position = Vector2(x * TILE_SIZE, GROUND_ROW * TILE_SIZE - 200)
	trigger.body_entered.connect(_on_level2_trigger_entered)
	add_child(trigger)

	var line = ColorRect.new()
	line.size = Vector2(8, 500)
	line.color = Color(0, 1, 1)
	line.position = Vector2(-4, -250)
	trigger.add_child(line)

func _on_spike_body_entered(body):
	if body.has_method("die"):
		body.die()

func _on_level2_trigger_entered(body):
	if body.has_method("die") and not level2_reached:
		level2_reached = true
		body.set_checkpoint(body.position)
		show_level2_notification()

func show_level2_notification():
	var canvas = CanvasLayer.new()
	canvas.layer = 10
	get_tree().get_root().add_child(canvas)

	var bg = ColorRect.new()
	bg.color = Color(0, 0, 0, 0.7)
	bg.size = Vector2(500, 150)
	bg.position = Vector2(350, 250)
	canvas.add_child(bg)

	var label = Label.new()
	label.text = "LEVEL 2!"
	label.add_theme_font_size_override("font_size", 80)
	label.modulate = Color(1, 1, 0)
	label.position = Vector2(370, 255)
	canvas.add_child(label)

	await get_tree().create_timer(2.5).timeout
	canvas.queue_free()

func _on_goal_entered(body):
	if body.has_method("die") and not stats_showing:
		GameData.time_finished = Time.get_ticks_msec()
		show_stats()

func show_stats():
	stats_showing = true

	var canvas = CanvasLayer.new()
	canvas.layer = 10
	get_tree().get_root().add_child(canvas)

	var panel = ColorRect.new()
	panel.color = Color(0, 0, 0, 0.9)
	panel.size = Vector2(700, 450)
	panel.position = Vector2(300, 150)
	canvas.add_child(panel)

	var difficulty_text = GameData.difficulty.to_upper()
	var time_text = "%.1f" % GameData.get_time_elapsed()
	var deaths_text = str(GameData.deaths)
	var jumps_text = str(GameData.jumps)

	var label = Label.new()
	label.text = """
	✦ LEVEL COMPLETE! ✦

	Difficulty:   %s
	Time:         %s seconds
	Deaths:       %s
	Jumps:        %s

	Press R to Play Again
	Press ESC for Main Menu
	""" % [difficulty_text, time_text, deaths_text, jumps_text]
	label.add_theme_font_size_override("font_size", 32)
	label.modulate = Color(1, 1, 0)
	label.position = Vector2(30, 20)
	canvas.add_child(label)

func _input(event):
	if not stats_showing:
		return
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_R:
			get_tree().reload_current_scene()
		if event.keycode == KEY_ESCAPE:
			get_tree().change_scene_to_file("res://Levels/HomeScreen.tscn")
