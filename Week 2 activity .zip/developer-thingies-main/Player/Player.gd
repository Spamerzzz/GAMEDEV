extends CharacterBody2D

var motion=Vector2(0,0)
const UP=Vector2(0,-1)
const GRAVITY=51
const SPEED=600
const JUMP_SPEED=850
const JUMP_SUBLIMIT=600
var jump_count=0
var wall_slide_speed=0
var wall_slide_max=500
var is_working = true
var earlyjump = false
var can_jump = false
var can_wall_jump = false
var checkpoint_position = Vector2(90, 0)

var left = "left"
var right = "right"
var jump = "jump"

func _physics_process(_delta):
	apply_gravity()
	set_velocity(motion)
	set_up_direction(UP)
	move_and_slide()
	motion = velocity
	up_collision()
	side_collision()
	auto_run()
	jumping()
	jump_breaker()
	early_jump()
	coyote_jump()
	animate()
	$Camera2D.offset = Vector2(400, 0)

func set_checkpoint(pos):
	checkpoint_position = pos

func die():
	GameData.deaths += 1
	position = checkpoint_position
	motion = Vector2(0, 0)

func up_collision():
	if is_on_ceiling():
		motion.y=1

func side_collision():
	if is_on_wall():
		can_wall_jump = true
		await get_tree().create_timer(0.1).timeout
		can_wall_jump = false

func apply_gravity():
	if is_on_floor() and motion.y > 0:
		jump_count=1
		motion.y=1
		wall_slide_speed=0
	elif is_on_wall() and motion.y > 0:
		if wall_slide_speed < wall_slide_max:
			motion.y += 20
			wall_slide_speed=motion.y
		else:
			wall_slide_speed=wall_slide_max
			motion.y += 20
	else:
		motion.y+=GRAVITY
		if motion.y > 0 and not is_on_wall():
			motion.y += float(GRAVITY)/4.0
		if position.y > 1000:
			die()

func auto_run():
	if motion.x < SPEED:
		motion.x = min(motion.x + 50, SPEED)

func jumping():
	if Input.is_action_pressed(jump) or earlyjump:
		if is_on_floor() or can_jump:
			GameData.jumps += 1
			motion.y = -JUMP_SPEED
			jump_count -= 1
		elif is_on_wall() and can_wall_jump:
			if not is_on_floor():
				motion.y = -JUMP_SPEED * 0.8
				motion.x = SPEED

func jump_breaker():
	if motion.y < -JUMP_SUBLIMIT and Input.is_action_just_released(jump):
		motion.y = -JUMP_SUBLIMIT

func early_jump():
	if jump_count == 0 and Input.is_action_just_pressed(jump):
		if not is_on_floor():
			if not is_on_wall():
				earlyjump = true
				await get_tree().create_timer(0.1).timeout
				earlyjump = false

func coyote_jump():
	if is_on_floor():
		can_jump = true
		$CoyoteTimer.start()

func _on_CoyoteTimer_timeout():
	can_jump = false

func animate():
	if is_working:
		if is_on_wall() and motion.y != 0:
			modulate = Color(1, 1, 0)
		elif is_on_floor() and motion.x != 0: 
			modulate = Color(0, 1, 0)
		elif is_on_floor() and motion.x == 0:
			modulate = Color(1, 0, 0)
		elif not is_on_floor() and not is_on_wall():
			modulate = Color(0, 1, 0)
