extends Control

var difficulty = "easy"

func _ready():
	pass

func _on_ez_pressed():
	difficulty = "easy"
	_highlight_button("easy")

func _on_med_pressed():
	difficulty = "medium"
	_highlight_button("medium")

func _on_hard_pressed():
	difficulty = "hard"
	_highlight_button("hard")

func _highlight_button(selected):
	$EZ.modulate = Color(1, 1, 1)
	$MED.modulate = Color(1, 1, 1)
	$HARD.modulate = Color(1, 1, 1)
	match selected:
		"easy":
			$EZ.modulate = Color(0, 1, 0)
		"medium":
			$MED.modulate = Color(1, 0.5, 0)
		"hard":
			$HARD.modulate = Color(1, 0, 0)

func _on_start_pressed():
	GameData.difficulty = difficulty
	GameData.reset_stats()
	get_tree().change_scene_to_file("res://Levels/Level.tscn")
