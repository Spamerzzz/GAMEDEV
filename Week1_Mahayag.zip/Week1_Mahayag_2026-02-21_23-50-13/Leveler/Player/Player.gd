extends CharacterBody2D

var motion=Vector2(0,0)
const UP=Vector2(0,-1)
const SPEED=600
const GRAVITY=51
const JUMP_SPEED=1200
const JUMP_SUBLIMIT = 400
const WORLD_LIMIT=3000
var jump_count=0
var wall_slide_speed=0
var wall_slide_max=500
var is_working = true
var earlyjump = false 
var can_jump = false
var can_wall_jump = false

var left = "left"
var right = "right"
var jump = "jump"


func _physics_process(_delta):
	apply_gravity()
	set_velocity(motion)
	set_up_direction(UP)
	move_and_slide()
	up_collision()
	side_collision()
	movement()
	jumping()
	jump_breaker()
	early_jump()
	coyote_jump()
	animate()


func up_collision():
	if is_on_ceiling():
		motion.y=1

func side_collision():
	if is_on_wall():
		if get_slide_collision(0).get_normal().x > 0:
			motion.x = 1
		else:
			motion.x = -1
		can_wall_jump = true
		await get_tree().create_timer(0.1).timeout
		can_wall_jump = false
	else:
		if is_on_wall():
			motion.x=0

func apply_gravity():
	if is_on_floor() and motion.y > 0:
		jump_count=1
		motion.y=1
	elif is_on_wall() and motion.y > 0:
		if wall_slide_speed < wall_slide_max:
			motion.y += 20
			wall_slide_speed=motion.y
		else:
			wall_slide_speed=wall_slide_max
			motion.y += 20
	else:
		motion.y+=GRAVITY
		if motion.y > 0 and not is_on_wall():
			motion.y += float(GRAVITY)/4.0
		if position.y > 1000:
			position = Vector2(90,0)
			motion = Vector2(0,1000)

func movement():
	if Input.is_action_pressed(left) and not Input.is_action_pressed(right):
		move_left()
	elif Input.is_action_pressed(right) and not Input.is_action_pressed(left):
		move_right()
	elif motion.x>0 and is_on_floor():
		motion.x = clamp(motion.x - 50, 0, SPEED)
	elif motion.x<0 and is_on_floor():
		motion.x = clamp(motion.x + 50, -SPEED, 0)

func move_left():
	if motion.x <= -SPEED:
		motion.x = -SPEED
	else:
		if is_on_wall():
			if motion.x == 1:
				await get_tree().create_timer(0.1).timeout
				motion.x -= 50
		else:
			motion.x-=50

func move_right():
	if motion.x >= SPEED:
		motion.x = SPEED
	else:
		if is_on_wall():
			if motion.x == -1:
				await get_tree().create_timer(0.1).timeout
				motion.x += 50
		else:
			motion.x+=50

func jumping():
	if Input.is_action_just_pressed(jump) or earlyjump:
		if is_on_floor() or can_jump:
			motion.y = -JUMP_SPEED
			jump_count-=1
		elif is_on_wall() and can_wall_jump:
			if not is_on_floor():
				if motion.x < 0:
					motion.y = -JUMP_SPEED*(0.8)
					motion.x = -SPEED
				else:
					motion.y = -JUMP_SPEED*(0.8)
					motion.x = SPEED

func jump_breaker():
	if motion.y < -JUMP_SUBLIMIT and Input.is_action_just_released(jump):
		motion.y = -JUMP_SUBLIMIT

func early_jump():
	if jump_count == 0 and Input.is_action_just_pressed(jump):
		if not is_on_floor():
			if not is_on_wall():
				earlyjump = true
				await get_tree().create_timer(0.1).timeout
				earlyjump = false

func coyote_jump():
	if is_on_floor():
		can_jump = true
		$CoyoteTimer.start()

func _on_CoyoteTimer_timeout():
	can_jump = false

func animate():
	if is_working:
		if is_on_wall() and motion.y != 0:
			modulate = Color(1, 1, 0)
		elif motion.x != 0 and not is_on_wall() and is_on_floor():
			modulate = Color(0, 1, 0)
		elif motion.x == 0 and not is_on_wall() and is_on_floor():
			modulate = Color(1, 0, 0)
		elif motion.y < -51 and not is_on_wall():
			modulate = Color(0, 1, 0)
